"""
Unified Vault - shared logging core.
All three modules (ips, ids, integrity) route alerts through here so
output/log format stays consistent across the platform.
"""
import json
import os
from datetime import datetime

LOG_DIR = os.environ.get("UNIFIED_VAULT_LOG_DIR", "./logs")


def _ensure_log_dir():
    os.makedirs(LOG_DIR, exist_ok=True)


def log_event(module: str, event_type: str, details: dict, severity: str = "INFO"):
    """
    module: 'ips' | 'ids' | 'integrity'
    event_type: short label e.g. 'PORT_SCAN', 'FILE_TAMPER', 'UNAUTHORIZED_ACCESS'
    details: event-specific payload
    severity: INFO | LOW | MEDIUM | HIGH
    """
    _ensure_log_dir()
    entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
        "module": module,
        "event_type": event_type,
        "severity": severity,
        "details": details,
    }
    path = os.path.join(LOG_DIR, "unified_vault.log")
    with open(path, "a") as f:
        f.write(json.dumps(entry) + "\n")
    alert(entry)
    return entry


def alert(entry: dict):
    """Console alert. Swap/extend for email, webhook, etc."""
    tag = {"HIGH": "!!!", "MEDIUM": "!!", "LOW": "!", "INFO": "*"}.get(entry["severity"], "*")
    print(f"[{tag}] [{entry['module'].upper()}] {entry['event_type']} - {entry['details']}")

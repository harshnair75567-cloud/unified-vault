# Architecture

Unified Vault combines three independent detection layers into one defense-in-depth toolkit.

```
                 ┌─────────────────────────┐
                 │        cli.py           │
                 │   single entrypoint      │
                 └───────────┬─────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼────┐          ┌─────▼─────┐         ┌─────▼──────┐
   │  ids/   │          │   ips/    │         │ integrity/ │
   │ Network │          │  Host     │         │   File     │
   │  layer  │          │  layer    │         │   layer    │
   └────┬────┘          └─────┬─────┘         └─────┬──────┘
        │                     │                      │
        └───────────┬─────────┴──────────┬───────────┘
                     │                    │
              ┌──────▼────────────────────▼──────┐
              │         core/logger.py           │
              │   unified logging + alerting     │
              └───────────────────────────────────┘
```

## Layers

**ids/** — Network Intrusion Detection (Scapy-based, socket honeypot listeners on common attacker-probed ports). Detects port scans and payload signatures before an attacker reaches the host.

**ips/** — Host-based Intrusion Prevention. Watches sensitive directories for Living-off-the-Land (LotL) access patterns and kills unauthorized processes touching monitored files in real time.

**integrity/** — File Integrity Monitoring (PyHash). Hash-based baseline/audit engine that detects tampering after the fact — the last line of defense if network and host layers are bypassed.

## Why unified

Each layer catches what the others miss: IDS blocks network-origin attacks, IPS catches local/LotL abuse IDS can't see, and FIM catches anything that slips past both. Routing all three through one `core/logger.py` gives a single timeline of events across the whole stack instead of three disconnected logs.

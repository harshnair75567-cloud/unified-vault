import os
import sys
import time
from engine import PyHashEngine
from audit import verify_integrity, report_findings

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from core.logger import log_event

def report_and_log(changes):
    report_findings(changes)
    for change_type, files in changes.items():
        for f in files:
            log_event("integrity", f"FILE_{change_type.upper()}", {"file": f},
                       severity="HIGH" if change_type == "modified" else "MEDIUM")

def main():
    # python main.py --baseline PATH | --audit PATH | --watch PATH [interval_seconds]
    mode = sys.argv[1]
    target = sys.argv[2]

    engine = PyHashEngine(target)

    if mode == "--baseline":
        engine.collect()
        engine.save_manifest("baseline.json")
        print("[+] Baseline created successfully.")

    elif mode == "--audit":
        print("[*] Starting Integrity Audit...")
        current_scan = engine.collect()
        results = verify_integrity("baseline.json", current_scan, secret_key="YOUR_HIDDEN_SALT")
        report_and_log(results)

    elif mode == "--watch":
        interval = int(sys.argv[3]) if len(sys.argv) > 3 else 30
        if not os.path.exists("baseline.json"):
            print("[*] No baseline found, creating one...")
            engine.collect()
            engine.save_manifest("baseline.json")
        print(f"[*] Watching {target} every {interval}s...")
        try:
            while True:
                time.sleep(interval)
                current_scan = engine.collect()
                results = verify_integrity("baseline.json", current_scan, secret_key="YOUR_HIDDEN_SALT")
                report_and_log(results)
        except KeyboardInterrupt:
            print("\n[!] Integrity watch stopped.")

if __name__ == "__main__":
    main()

# HS-IPS
HS-IPS is a proactive, session-aware security engine designed to protect sensitive Linux environments from unauthorized data access and "Living off the Land" (LotL) attacks. Unlike traditional passive logging tools, HS-IPS implements a real-time defense-in-depth strategy by monitoring the system's metadata "heartbeat."
if it doesnt work its probably because the kernel isnt being updated to resolve this using 

sudo mount -o remount,strictatime /

will solve it

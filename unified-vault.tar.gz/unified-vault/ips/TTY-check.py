import os
import sys
import time
import json
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.logger import log_event
from core.config_loader import get_config

_cfg = get_config()["ips"]
WATCH_ZONES = _cfg["watch_zones"]
SAFE_TOOLS = _cfg["safe_tools"]

LOG_FILE = "/home/harsh/Watchmans_Notepad.json"

def get_my_tty():
    """Finds the ID of the terminal you are currently using."""
    try:
        return subprocess.check_output(["tty"]).decode().strip().replace("/dev/", "")
    except:
        return "unknown"

def terminate_spy(target_file, architect_tty):
    try:
        time.sleep(0.1)
        pid = subprocess.check_output(["lsof", "-t", target_file]).decode().strip()
        
        if pid:
            proc_name = subprocess.check_output(["ps", "-p", pid, "-o", "comm="]).decode().strip()
            try:
                proc_tty = subprocess.check_output(["ps", "-p", pid, "-o", "tty="]).decode().strip()
            except:
                proc_tty = "?"

            if proc_name in SAFE_TOOLS and proc_tty == architect_tty:
                return False

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            subprocess.run(["sudo", "kill", "-9", pid])

            log_event("ips", "UNAUTHORIZED_ACCESS", {
                "file": target_file, "tool": proc_name, "tty": proc_tty, "action": "TERMINATE"
            }, severity="HIGH")

            with open(LOG_FILE, "a") as f:
                log_entry = {
                    "time": timestamp, 
                    "file": target_file, 
                    "tool": proc_name, 
                    "tty": proc_tty,
                    "action": "TERMINATE"
                }
                f.write(json.dumps(log_entry) + "\n")
            return True
    except:
        return False
    return False

def get_snapshot(zones):
    file_map = {}
    for zone in zones:
        if not os.path.exists(zone): continue
        for root, _, files in os.walk(zone):
            for name in files:
                path = os.path.join(root, name)
                try:
                    file_map[path] = os.stat(path).st_atime
                except: continue
    return file_map

if __name__ == "__main__":
    MY_TTY = get_my_tty()
    print(f"--- Sentinel Online ---")
    print(f"Architect Session: {MY_TTY}")
    
    pulses = get_snapshot(WATCH_ZONES)
    print(f"Rigged {len(pulses)} tripwires. Monitoring...")

    try:
        while True:
            current_pulses = get_snapshot(WATCH_ZONES)
            for path, atime in current_pulses.items():
                if path in pulses:
                    if atime != pulses[path]:
                        if terminate_spy(path, MY_TTY):
                            pulses[path] = os.stat(path).st_atime
                else:
                    pulses[path] = atime
            time.sleep(0.8)
    except KeyboardInterrupt:
        print("\n[!] Disarmed.")
